'use strict';
require('dotenv').config?.();
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const webpush = require('web-push');
const nodemailer = require('nodemailer');
const { db, getSetting, setSetting } = require('./src/db');
const { ALL, generateChallenge } = require('./src/challenges');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || getSetting('jwt_secret') || (() => {
  const s = crypto.randomBytes(32).toString('hex');
  setSetting('jwt_secret', s);
  return s;
})();

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Utilidades de fecha (Europe/Madrid) ----------
function madridParts(date = new Date()) {
  const fmt = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Madrid', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false, weekday: 'short',
  });
  const parts = {};
  for (const p of fmt.formatToParts(date)) parts[p.type] = p.value;
  const dateKey = `${parts.year}-${parts.month}-${parts.day}`;
  const hour = parseInt(parts.hour, 10) % 24;
  const minute = parseInt(parts.minute, 10);
  // weekday: Mon..Sun short in en -> map
  const wdMap = { Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6, Sun: 0 };
  const weekday = wdMap[parts.weekday] ?? 0;
  // lunes de esta semana
  const d = new Date(Date.UTC(+parts.year, +parts.month - 1, +parts.day));
  const diffToMonday = (weekday + 6) % 7; // 0 si lunes
  d.setUTCDate(d.getUTCDate() - diffToMonday);
  const mondayKey = d.toISOString().slice(0, 10);
  return {
    dateKey, hour, minute, weekday, mondayKey,
    monthKey: `${parts.year}-${parts.month}`,
    yearKey: parts.year,
    time: `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`,
  };
}
function isResultsVisible() {
  const { hour } = madridParts();
  return hour >= 21; // 21:00–00:00
}
function addDays(dateKey, days) {
  const d = new Date(dateKey + 'T12:00:00Z');
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}
function genInviteCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let s = '';
  for (let i = 0; i < 8; i++) s += chars[crypto.randomInt(chars.length)];
  return s;
}
function ensureInviteCode() {
  let code = getSetting('invite_code');
  if (!code) { code = genInviteCode(); setSetting('invite_code', code); }
  return code;
}
function seedChallenges() {
  const count = db.prepare('SELECT COUNT(*) c FROM challenges').get().c;
  if (count >= ALL.length) return;
  const ins = db.prepare('INSERT OR IGNORE INTO challenges(text,type,difficulty,weekly) VALUES(?,?,?,?)');
  const tx = db.transaction(() => { for (const c of ALL) ins.run(c.text, c.type, c.difficulty, c.weekly); });
  tx();
  console.log(`[seed] ${ALL.length} retos cargados`);
}

// ---------- Generación infinita de retos nuevos ----------
// Mantiene siempre un colchón de retos sin usar; cuando se agota,
// genera retos nuevos únicos automáticamente (nunca se repiten).
function ensurePool(kind, minFresh = 30) {
  const weekly = kind === 'weekly' ? 1 : 0;
  const fresh = db.prepare(
    'SELECT COUNT(*) c FROM challenges WHERE weekly = ? AND (last_assigned IS NULL OR last_assigned < date(?, \'-7 days\'))'
  ).get(weekly, madridParts().dateKey).c;
  if (fresh >= minFresh) return 0;
  const existing = new Set(db.prepare('SELECT text FROM challenges').all().map(r => r.text));
  const need = Math.min(100, (minFresh - fresh) + 50);
  const ins = db.prepare('INSERT OR IGNORE INTO challenges(text,type,difficulty,weekly) VALUES(?,?,?,?)');
  let created = 0;
  for (let i = 0; i < need; i++) {
    const c = generateChallenge(kind, existing);
    if (!c) break;
    const info = ins.run(c.text, c.type, c.difficulty, c.weekly);
    if (info.changes) { existing.add(c.text); created++; }
  }
  if (created) console.log(`[pool] ${created} retos nuevos ${kind} generados (total ${db.prepare('SELECT COUNT(*) c FROM challenges').get().c})`);
  return created;
}

// ---------- Selección adaptativa de retos ----------
function pickChallenge(kind, dateKey) {
  const weekly = kind === 'weekly' ? 1 : 0;
  ensurePool(kind, kind === 'weekly' ? 20 : 30);
  const rows = db.prepare('SELECT * FROM challenges WHERE weekly = ?').all(weekly);
  if (!rows.length) return null;
  const scored = rows.map(r => {
    const avg = r.score_count ? r.score_sum / r.score_count : 5;
    let score = 50;
    score -= r.assigned_count * 4;                       // menos repetidos
    score += r.completed_count * 8;                      // los que se completan suben
    score += (avg - 5) * 6;                              // los que gustan suben
    if (r.last_assigned === dateKey) score -= 1000;
    else if (r.last_assigned && dateKey >= r.last_assigned) {
      const days = Math.round((new Date(dateKey) - new Date(r.last_assigned)) / 86400000);
      if (days < 7) score -= (7 - days) * 8;             // enfriamiento 7 días
    }
    score += Math.random() * 25;                         // exploración
    return { r, score };
  }).sort((a, b) => b.score - a.score);
  const top = scored[0].r;
  db.prepare('UPDATE challenges SET assigned_count = assigned_count + 1, last_assigned = ? WHERE id = ?')
    .run(dateKey, top.id);
  return top;
}
function ensureAssignment(kind, dateKey) {
  let a = db.prepare('SELECT * FROM assignments WHERE kind = ? AND date_key = ?').get(kind, dateKey);
  if (a) return a;
  const ch = pickChallenge(kind, dateKey);
  if (!ch) return null;
  const info = db.prepare('INSERT INTO assignments(challenge_id, kind, date_key) VALUES(?,?,?)')
    .run(ch.id, kind, dateKey);
  a = db.prepare('SELECT * FROM assignments WHERE id = ?').get(info.lastInsertRowid);
  console.log(`[reto] nuevo ${kind} ${dateKey}: ${ch.text.slice(0, 60)}…`);
  sendPushToAll(
    kind === 'weekly' ? '🏆 Nuevo reto semanal' : '⚡ Nuevo reto diario',
    ch.text.slice(0, 120),
    '/'
  );
  return a;
}

// ---------- Resultados y ganadores de periodo ----------
function submissionAvg(subId) {
  const r = db.prepare('SELECT AVG(score) a, COUNT(*) c FROM votes WHERE submission_id = ?').get(subId);
  return { avg: r.c ? r.a : null, count: r.c };
}
function finalizeAssignment(assignment) {
  const existing = db.prepare('SELECT * FROM results WHERE assignment_id = ?').get(assignment.id);
  if (existing) return existing;
  const subs = db.prepare('SELECT * FROM submissions WHERE assignment_id = ?').all(assignment.id);
  let winner = null, winnerAvg = null;
  for (const s of subs) {
    const { avg } = submissionAvg(s.id);
    if (avg != null && (winnerAvg == null || avg > winnerAvg)) { winner = s; winnerAvg = avg; }
    // actualizar stats del reto (aprendizaje)
    if (avg != null) {
      db.prepare(`UPDATE challenges SET score_sum = score_sum + ?, score_count = score_count + 1,
                  completed_count = completed_count + 1 WHERE id = ?`).run(avg, assignment.challenge_id);
    }
  }
  const info = db.prepare('INSERT INTO results(assignment_id, winner_user_id, winner_avg) VALUES(?,?,?)')
    .run(assignment.id, winner ? winner.user_id : null, winnerAvg);
  const res = db.prepare('SELECT * FROM results WHERE id = ?').get(info.lastInsertRowid);
  if (winner) {
    const u = db.prepare('SELECT username FROM users WHERE id = ?').get(winner.user_id);
    sendPushToAll('🏁 ¡Tenemos ganador!', `${u.username} gana con ${winnerAvg.toFixed(2)} puntos`, '/');
  }
  return res;
}
function periodTotals(kind, periodKey) {
  // kind: weekly|monthly|yearly ; periodKey: monday | YYYY-MM | YYYY
  let where = '', params = [];
  if (kind === 'weekly') {
    const end = addDays(periodKey, 7);
    where = 'a.kind IN (\'daily\',\'weekly\') AND a.date_key >= ? AND a.date_key < ?';
    params = [periodKey, end];
  } else if (kind === 'monthly') {
    where = 'a.kind IN (\'daily\',\'weekly\') AND substr(a.date_key,1,7) = ?';
    params = [periodKey];
  } else {
    where = 'a.kind IN (\'daily\',\'weekly\') AND substr(a.date_key,1,4) = ?';
    params = [periodKey];
  }
  const rows = db.prepare(`
    SELECT u.id, u.username, s.id AS sub_id
    FROM submissions s
    JOIN assignments a ON a.id = s.assignment_id
    JOIN users u ON u.id = s.user_id
    WHERE ${where}`).all(...params);
  const totals = new Map();
  for (const r of rows) {
    const { avg } = submissionAvg(r.sub_id);
    if (avg == null) continue;
    if (!totals.has(r.id)) totals.set(r.id, { id: r.id, username: r.username, total: 0, wins: 0, subs: 0 });
    const t = totals.get(r.id);
    t.total += avg; t.subs += 1;
  }
  // victorias: ganador de cada assignment en el periodo
  const wins = db.prepare(`
    SELECT r.winner_user_id AS uid, COUNT(*) c
    FROM results r JOIN assignments a ON a.id = r.assignment_id
    WHERE ${where} AND r.winner_user_id IS NOT NULL
    GROUP BY r.winner_user_id`).all(...params);
  for (const w of wins) {
    if (totals.has(w.uid)) totals.get(w.uid).wins = w.c;
    else totals.set(w.uid, { id: w.uid, username: '', total: 0, wins: w.c, subs: 0 });
  }
  return [...totals.values()].sort((a, b) => b.total - a.total || b.wins - a.wins);
}
function finalizePeriod(kind, periodKey) {
  const existing = db.prepare('SELECT * FROM period_winners WHERE kind = ? AND period_key = ?').get(kind, periodKey);
  if (existing) return existing;
  const totals = periodTotals(kind, periodKey);
  const top = totals[0] || null;
  const info = db.prepare('INSERT INTO period_winners(kind, period_key, user_id, total_points, wins) VALUES(?,?,?,?,?)')
    .run(kind, periodKey, top ? top.id : null, top ? top.total : null, top ? top.wins : 0);
  if (top) {
    const label = kind === 'weekly' ? 'semana' : kind === 'monthly' ? 'mes' : 'año';
    sendPushToAll(`👑 Ganador del ${label}`, `${top.username} gana el ${label} con ${top.total.toFixed(2)} puntos`, '/#ranking');
  }
  return db.prepare('SELECT * FROM period_winners WHERE id = ?').get(info.lastInsertRowid);
}
function tick() {
  try {
    const p = madridParts();
    ensurePool('daily', 30);
    ensurePool('weekly', 20);
    ensureAssignment('daily', p.dateKey);
    ensureAssignment('weekly', p.mondayKey);
    // finalizar reto de hoy a las 21:00
    if (p.hour >= 21) {
      const todayDaily = db.prepare("SELECT * FROM assignments WHERE kind='daily' AND date_key=?").get(p.dateKey);
      if (todayDaily) finalizeAssignment(todayDaily);
    }
    // finalizar periodos terminados
    if (p.weekday === 1 && p.hour === 0 && p.minute < 2) {
      // lunes 00:00 -> semana pasada
      const lastMonday = addDays(p.mondayKey, -7);
      finalizePeriod('weekly', lastMonday);
    }
    if (p.dateKey.endsWith('-01') && p.hour === 0 && p.minute < 2) {
      const prevMonth = addDays(p.dateKey, -1).slice(0, 7);
      finalizePeriod('monthly', prevMonth);
    }
    if (p.dateKey.endsWith('-01-01') && p.hour === 0 && p.minute < 2) {
      finalizePeriod('yearly', String(+p.yearKey - 1));
    }
    // recordatorio 20:00 si falta subir/votar
    if (p.hour === 20 && p.minute < 2) {
      const key = 'reminder_' + p.dateKey;
      if (!getSetting(key)) {
        setSetting(key, '1');
        sendPushToAll('⏰ ¡Última hora!', 'Te quedan 40 minutos para subir tu reto y votar. ¡A por ello!', '/');
      }
    }
  } catch (e) { console.error('[tick]', e.message); }
}

// ---------- Push ----------
function ensureVapid() {
  let pub = getSetting('vapid_public'), priv = getSetting('vapid_private');
  if (!pub || !priv) {
    if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
      pub = process.env.VAPID_PUBLIC_KEY; priv = process.env.VAPID_PRIVATE_KEY;
    } else {
      const keys = webpush.generateVAPIDKeys();
      pub = keys.publicKey; priv = keys.privateKey;
    }
    setSetting('vapid_public', pub); setSetting('vapid_private', priv);
  }
  webpush.setVapidDetails(
    process.env.VAPID_SUBJECT || 'mailto:admin@example.com', pub, priv
  );
  return pub;
}
async function sendPushToAll(title, body, url = '/') {
  try {
    const subs = db.prepare('SELECT * FROM push_subscriptions').all();
    if (!subs.length) return;
    const payload = JSON.stringify({ title, body, url });
    for (const s of subs) {
      try {
        await webpush.sendNotification({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, payload);
      } catch (e) {
        if (e.statusCode === 410 || e.statusCode === 404) {
          db.prepare('DELETE FROM push_subscriptions WHERE id = ?').run(s.id);
        }
      }
    }
  } catch (e) { console.error('[push]', e.message); }
}

// ---------- Email (recuperar contraseña) ----------
function getMailer() {
  if (!process.env.SMTP_HOST) return null;
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: +(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === 'true',
    auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
  });
}
async function sendResetEmail(user, token) {
  const link = `${process.env.APP_URL || 'http://localhost:' + PORT}/#reset?token=${token}`;
  const mailer = getMailer();
  if (!mailer) {
    console.log(`[reset] (sin SMTP) enlace para ${user.email}: ${link}`);
    return;
  }
  await mailer.sendMail({
    from: process.env.SMTP_FROM || 'Reto Diario <no-reply@example.com>',
    to: user.email,
    subject: 'Restablece tu contraseña — Reto Diario',
    text: `Hola ${user.username},\n\nPulsa este enlace para crear una contraseña nueva (válido 1 hora):\n${link}\n\nSi no lo pediste tú, ignora este correo.`,
  });
}

// ---------- Auth ----------
function auth(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'No autenticado' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch { return res.status(401).json({ error: 'Token inválido' }); }
}
function adminOnly(req, res, next) {
  if (!req.user.is_admin) return res.status(403).json({ error: 'Solo admin' });
  next();
}
const validEmail = e => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e || '');
const validUser = u => /^[a-zA-Z0-9_]{3,20}$/.test(u || '');

app.get('/api/health', (req, res) => res.json({ ok: true, time: madridParts() }));
app.get('/api/config', (req, res) => {
  res.json({
    vapidPublicKey: ensureVapid(),
    challengeCount: db.prepare('SELECT COUNT(*) c FROM challenges').get().c,
    inviteRequired: db.prepare('SELECT COUNT(*) c FROM users').get().c > 0,
  });
});

app.post('/api/auth/register', async (req, res) => {
  const { email, username, password, inviteCode } = req.body || {};
  if (!validEmail(email)) return res.status(400).json({ error: 'Email no válido' });
  if (!validUser(username)) return res.status(400).json({ error: 'Usuario: 3-20 caracteres (letras, números, _)' });
  if (!password || password.length < 6) return res.status(400).json({ error: 'Contraseña mínimo 6 caracteres' });
  const userCount = db.prepare('SELECT COUNT(*) c FROM users').get().c;
  const isFirst = userCount === 0;
  if (!isFirst) {
    if ((inviteCode || '').trim().toUpperCase() !== ensureInviteCode()) {
      return res.status(403).json({ error: 'Código de invitación incorrecto' });
    }
  }
  const hash = await bcrypt.hash(password, 10);
  try {
    const info = db.prepare('INSERT INTO users(email, username, password_hash, is_admin) VALUES(?,?,?,?)')
      .run(email.toLowerCase(), username, hash, isFirst ? 1 : 0);
    const user = db.prepare('SELECT id, email, username, is_admin FROM users WHERE id = ?').get(info.lastInsertRowid);
    const token = jwt.sign(user, JWT_SECRET, { expiresIn: '30d' });
    res.json({ token, user, inviteCode: isFirst ? ensureInviteCode() : undefined });
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return res.status(409).json({ error: 'Ese email o usuario ya existe' });
    throw e;
  }
});
app.post('/api/auth/login', async (req, res) => {
  const { identifier, password } = req.body || {};
  if (!identifier || !password) return res.status(400).json({ error: 'Faltan datos' });
  const user = db.prepare('SELECT * FROM users WHERE email = ? OR username = ?')
    .get(identifier.toLowerCase(), identifier);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ error: 'Credenciales incorrectas' });
  }
  const safe = { id: user.id, email: user.email, username: user.username, is_admin: user.is_admin };
  res.json({ token: jwt.sign(safe, JWT_SECRET, { expiresIn: '30d' }), user: safe });
});
app.get('/api/auth/me', auth, (req, res) => {
  const u = db.prepare('SELECT id, email, username, is_admin, created_at FROM users WHERE id = ?').get(req.user.id);
  res.json({ user: u });
});
app.post('/api/auth/forgot', async (req, res) => {
  const { email } = req.body || {};
  // Respuesta genérica para no filtrar qué emails existen
  if (validEmail(email)) {
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase());
    if (user) {
      const token = crypto.randomBytes(32).toString('hex');
      const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
      const expires = new Date(Date.now() + 3600000).toISOString().replace('T', ' ').slice(0, 19);
      db.prepare('UPDATE password_resets SET used = 1 WHERE user_id = ? AND used = 0').run(user.id);
      db.prepare('INSERT INTO password_resets(user_id, token_hash, expires_at) VALUES(?,?,?)')
        .run(user.id, tokenHash, expires);
      try { await sendResetEmail(user, token); } catch (e) { console.error('[reset email]', e.message); }
    }
  }
  res.json({ ok: true, message: 'Si ese email está registrado, te hemos enviado un enlace para restablecer tu contraseña.' });
});
app.post('/api/auth/reset', async (req, res) => {
  const { token, password } = req.body || {};
  if (!token || !password || password.length < 6) {
    return res.status(400).json({ error: 'Token y contraseña (mín. 6) requeridos' });
  }
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const row = db.prepare('SELECT * FROM password_resets WHERE token_hash = ? AND used = 0').get(tokenHash);
  if (!row) return res.status(400).json({ error: 'Enlace no válido o ya usado' });
  const now = new Date().toISOString().replace('T', ' ').slice(0, 19);
  if (row.expires_at < now) return res.status(400).json({ error: 'Enlace caducado. Pide uno nuevo.' });
  const hash = await bcrypt.hash(password, 10);
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, row.user_id);
  db.prepare('UPDATE password_resets SET used = 1 WHERE id = ?').run(row.id);
  res.json({ ok: true });
});

// ---------- Retos de hoy ----------
function assignmentView(a, userId) {
  const ch = db.prepare('SELECT * FROM challenges WHERE id = ?').get(a.challenge_id);
  const mySub = db.prepare('SELECT * FROM submissions WHERE assignment_id = ? AND user_id = ?').get(a.id, userId);
  const totalSubs = db.prepare('SELECT COUNT(*) c FROM submissions WHERE assignment_id = ?').get(a.id).c;
  const totalUsers = db.prepare('SELECT COUNT(*) c FROM users').get().c;
  const result = db.prepare('SELECT * FROM results WHERE assignment_id = ?').get(a.id);
  return {
    assignmentId: a.id, kind: a.kind, dateKey: a.date_key,
    challenge: { id: ch.id, text: ch.text, type: ch.type, difficulty: ch.difficulty },
    mySubmission: mySub ? { id: mySub.id, mediaUrl: '/uploads/' + path.basename(mySub.media_path), mediaType: mySub.media_type, duration: mySub.duration } : null,
    totalSubs, totalUsers,
    resultsVisible: isResultsVisible(),
    result: result ? { winnerUserId: result.winner_user_id, winnerAvg: result.winner_avg } : null,
  };
}
app.get('/api/challenges/today', auth, (req, res) => {
  const p = madridParts();
  const daily = ensureAssignment('daily', p.dateKey);
  const weekly = ensureAssignment('weekly', p.mondayKey);
  res.json({
    now: p, resultsVisible: isResultsVisible(),
    daily: assignmentView(daily, req.user.id),
    weekly: assignmentView(weekly, req.user.id),
  });
});

// ---------- Subidas ----------
const uploadDir = path.join(__dirname, 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({
  destination: uploadDir,
  filename: (req, file, cb) => cb(null, crypto.randomBytes(8).toString('hex') + path.extname(file.originalname || '')),
});
const upload = multer({
  storage,
  limits: { fileSize: 60 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = file.mimetype.startsWith('image/') || file.mimetype.startsWith('video/');
    cb(ok ? null : new Error('Solo imágenes o vídeos'), ok);
  },
});
function probeDuration(filePath) {
  try {
    const out = execFileSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', filePath], { timeout: 10000 }).toString().trim();
    return parseFloat(out);
  } catch { return null; }
}
app.post('/api/submissions', auth, upload.single('file'), (req, res) => {
  const assignmentId = +req.body.assignmentId;
  if (!assignmentId || !req.file) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.status(400).json({ error: 'Falta el archivo o el reto' });
  }
  const a = db.prepare('SELECT * FROM assignments WHERE id = ?').get(assignmentId);
  if (!a) return res.status(404).json({ error: 'Reto no encontrado' });
  const ch = db.prepare('SELECT * FROM challenges WHERE id = ?').get(a.challenge_id);
  const isVideo = req.file.mimetype.startsWith('video/');
  if (ch.type === 'foto' && isVideo) { fs.unlinkSync(req.file.path); return res.status(400).json({ error: 'Este reto pide una foto' }); }
  if (ch.type === 'video' && !isVideo) { fs.unlinkSync(req.file.path); return res.status(400).json({ error: 'Este reto pide un vídeo' }); }
  let duration = null;
  if (isVideo) {
    duration = probeDuration(req.file.path) ?? parseFloat(req.body.duration);
    const max = a.kind === 'weekly' ? 30 : 10;
    if (!duration || isNaN(duration)) { fs.unlinkSync(req.file.path); return res.status(400).json({ error: 'No se pudo leer la duración del vídeo' }); }
    if (duration > max + 0.5) { fs.unlinkSync(req.file.path); return res.status(400).json({ error: `El vídeo dura ${duration.toFixed(1)}s y el máximo es ${max}s` }); }
  }
  const existing = db.prepare('SELECT * FROM submissions WHERE assignment_id = ? AND user_id = ?').get(a.id, req.user.id);
  if (existing) {
    try { fs.unlinkSync(existing.media_path); } catch {}
    db.prepare('UPDATE submissions SET media_path=?, media_type=?, duration=?, updated_at=datetime(\'now\') WHERE id=?')
      .run(req.file.path, isVideo ? 'video' : 'image', duration, existing.id);
    return res.json({ ok: true, updated: true });
  }
  db.prepare('INSERT INTO submissions(assignment_id, user_id, media_path, media_type, duration) VALUES(?,?,?,?,?)')
    .run(a.id, req.user.id, req.file.path, isVideo ? 'video' : 'image', duration);
  res.json({ ok: true });
});

// ---------- Ver entregas y votar (secreto hasta 21:00) ----------
app.get('/api/submissions/:assignmentId', auth, (req, res) => {
  const a = db.prepare('SELECT * FROM assignments WHERE id = ?').get(+req.params.assignmentId);
  if (!a) return res.status(404).json({ error: 'Reto no encontrado' });
  const visible = isResultsVisible();
  const rows = db.prepare(`
    SELECT s.*, u.username FROM submissions s JOIN users u ON u.id = s.user_id
    WHERE s.assignment_id = ? ORDER BY s.created_at`).all(a.id);
  const subs = rows.map(s => {
    const myVote = db.prepare('SELECT score FROM votes WHERE submission_id = ? AND voter_id = ?').get(s.id, req.user.id);
    const { avg, count } = submissionAvg(s.id);
    return {
      id: s.id, userId: s.user_id, username: s.username,
      mediaUrl: '/uploads/' + path.basename(s.media_path), mediaType: s.media_type, duration: s.duration,
      isMine: s.user_id === req.user.id,
      myVote: myVote ? myVote.score : null,
      // secreto: antes de 21:00 no se revelan medias ni quién votó qué
      avg: visible ? avg : null, voteCount: visible ? count : null,
    };
  });
  res.json({ assignmentId: a.id, kind: a.kind, dateKey: a.date_key, resultsVisible: visible, submissions: subs });
});
app.post('/api/votes', auth, (req, res) => {
  const { submissionId, score } = req.body || {};
  const s = db.prepare('SELECT * FROM submissions WHERE id = ?').get(+submissionId);
  if (!s) return res.status(404).json({ error: 'Entrega no encontrada' });
  if (s.user_id === req.user.id) return res.status(400).json({ error: 'No puedes votar tu propia entrega' });
  let sc = Math.round(parseFloat(score) * 100) / 100;
  if (isNaN(sc) || sc < 1 || sc > 10) return res.status(400).json({ error: 'La nota debe estar entre 1.00 y 10.00' });
  db.prepare(`INSERT INTO votes(submission_id, voter_id, score) VALUES(?,?,?)
              ON CONFLICT(submission_id, voter_id) DO UPDATE SET score = excluded.score`)
    .run(s.id, req.user.id, sc);
  res.json({ ok: true, score: sc });
});

// ---------- Ranking / ganadores de periodo ----------
app.get('/api/leaderboard', auth, (req, res) => {
  const p = madridParts();
  const period = req.query.period || 'week';
  let kind, key, label;
  if (period === 'week') { kind = 'weekly'; key = p.mondayKey; label = 'Esta semana'; }
  else if (period === 'month') { kind = 'monthly'; key = p.monthKey; label = 'Este mes'; }
  else if (period === 'year') { kind = 'yearly'; key = p.yearKey; label = 'Este año'; }
  else { kind = 'all'; label = 'Histórico'; }
  let totals;
  if (kind === 'all') {
    // histórico: suma de todos los periodos finalizados + actual
    const users = db.prepare('SELECT id, username FROM users').all();
    totals = users.map(u => {
      const rows = db.prepare(`SELECT s.id FROM submissions s JOIN assignments a ON a.id=s.assignment_id WHERE s.user_id=?`).all(u.id);
      let total = 0, subs = 0;
      for (const r of rows) { const { avg } = submissionAvg(r.id); if (avg != null) { total += avg; subs++; } }
      const wins = db.prepare('SELECT COUNT(*) c FROM results WHERE winner_user_id=?').get(u.id).c;
      return { id: u.id, username: u.username, total, wins, subs };
    }).sort((a, b) => b.total - a.total || b.wins - a.wins);
  } else {
    totals = periodTotals(kind, key);
  }
  const winner = db.prepare('SELECT * FROM period_winners WHERE kind=? AND period_key=?').get(kind, key);
  res.json({ period, label, totals, finalizedWinner: winner || null });
});
app.get('/api/period-winners', auth, (req, res) => {
  const rows = db.prepare(`
    SELECT pw.*, u.username FROM period_winners pw LEFT JOIN users u ON u.id = pw.user_id
    ORDER BY pw.finalized_at DESC LIMIT 50`).all();
  res.json({ winners: rows });
});

// ---------- Push API ----------
app.get('/api/push/vapid-public-key', (req, res) => res.json({ key: ensureVapid() }));
app.post('/api/push/subscribe', auth, (req, res) => {
  const { endpoint, keys } = req.body || {};
  if (!endpoint || !keys?.p256dh || !keys?.auth) return res.status(400).json({ error: 'Suscripción inválida' });
  db.prepare(`INSERT INTO push_subscriptions(user_id, endpoint, p256dh, auth) VALUES(?,?,?,?)
              ON CONFLICT(endpoint) DO UPDATE SET user_id=excluded.user_id, p256dh=excluded.p256dh, auth=excluded.auth`)
    .run(req.user.id, endpoint, keys.p256dh, keys.auth);
  res.json({ ok: true });
});
app.delete('/api/push/subscribe', auth, (req, res) => {
  db.prepare('DELETE FROM push_subscriptions WHERE user_id = ?').run(req.user.id);
  res.json({ ok: true });
});

// ---------- Admin ----------
app.get('/api/admin/invite', auth, adminOnly, (req, res) => res.json({ inviteCode: ensureInviteCode() }));
app.post('/api/admin/invite/regenerate', auth, adminOnly, (req, res) => {
  const code = genInviteCode();
  setSetting('invite_code', code);
  res.json({ inviteCode: code });
});
app.get('/api/admin/stats', auth, adminOnly, (req, res) => {
  res.json({
    users: db.prepare('SELECT COUNT(*) c FROM users').get().c,
    challenges: db.prepare('SELECT COUNT(*) c FROM challenges').get().c,
    challengesDaily: db.prepare('SELECT COUNT(*) c FROM challenges WHERE weekly=0').get().c,
    challengesWeekly: db.prepare('SELECT COUNT(*) c FROM challenges WHERE weekly=1').get().c,
    submissions: db.prepare('SELECT COUNT(*) c FROM submissions').get().c,
    votes: db.prepare('SELECT COUNT(*) c FROM votes').get().c,
    pushSubs: db.prepare('SELECT COUNT(*) c FROM push_subscriptions').get().c,
  });
});
// Generar retos nuevos a mano (la app también lo hace sola cuando se agotan)
app.post('/api/admin/challenges/generate', auth, adminOnly, (req, res) => {
  const kind = req.body?.kind === 'weekly' ? 'weekly' : 'daily';
  const count = Math.min(200, Math.max(1, parseInt(req.body?.count || '50', 10)));
  const existing = new Set(db.prepare('SELECT text FROM challenges').all().map(r => r.text));
  const ins = db.prepare('INSERT OR IGNORE INTO challenges(text,type,difficulty,weekly) VALUES(?,?,?,?)');
  let created = 0;
  for (let i = 0; i < count; i++) {
    const c = generateChallenge(kind, existing);
    if (!c) break;
    if (ins.run(c.text, c.type, c.difficulty, c.weekly).changes) { existing.add(c.text); created++; }
  }
  res.json({ ok: true, created, total: db.prepare('SELECT COUNT(*) c FROM challenges').get().c });
});

// ---------- Arranque ----------
seedChallenges();
ensureInviteCode();
ensureVapid();
tick();
setInterval(tick, 60000);
app.listen(PORT, '0.0.0.0', () => console.log(`Reto Diario en http://0.0.0.0:${PORT}`));
