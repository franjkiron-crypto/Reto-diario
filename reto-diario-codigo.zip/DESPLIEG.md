# 🚀 Subir Reto Diario a internet (gratis) — guía paso a paso

## Respuesta corta a tus preguntas
- **¿Se puede cambiar color, nombre, reglas después de subirla?** Sí, siempre. Editas el código → lo subes a GitHub → Render lo actualiza solo en 1-2 minutos. Los usuarios, votos y retos se conservan (están en el disco persistente, no en el código).
- **¿Retos infinitos sin repetición?** Ya está hecho: la app genera retos nuevos automáticamente cuando se agotan (ver abajo).

---

## Paso 1 — Subir el código a GitHub (5 min)

**Opción A (recomendada, con git):**
1. Crea una cuenta en https://github.com (si no tienes).
2. Ve a https://github.com/new → nombre `reto-diario` → **Create repository** (sin README, sin .gitignore).
3. En tu ordenador, dentro de la carpeta del proyecto:
   ```bash
   git remote add origin https://github.com/TU-USUARIO/reto-diario.git
   git push -u origin main
   ```
   El repo local ya está inicializado y con el primer commit hecho. GitHub te pedirá iniciar sesión en tu propio ordenador; no compartas aquí contraseñas ni tokens.

**Opción B (sin git, desde el navegador):**
1. Descarga `reto-diario.zip` y descomprímelo en tu ordenador.
2. En GitHub: **New repository** → `reto-diario` → **Add file → Upload files**.
3. Arrastra al navegador los archivos y carpetas del proyecto ya descomprimidos (no el ZIP como un único archivo) y pulsa **Commit changes**.

## Paso 2 — Desplegar en Render (gratis, 5 min)

1. Entra en https://render.com → **New → Web Service**.
2. Conecta tu repositorio `reto-diario`.
3. Render detecta el `render.yaml` incluido y lo configura solo:
   - Build: `npm install` · Start: `node server.js` · Disco persistente de 1 GB en `/data`.
4. En **Environment** añade:
   - `APP_URL` = la URL que te dé Render (ej. `https://reto-diario.onrender.com`)
   - `JWT_SECRET` = cualquier texto largo aleatorio (Render puede generarlo)
5. Pulsa **Create Web Service**. En 2-3 minutos tendrás la app en internet. 🎉

**Railway (alternativa):** https://railway.app → New Project → Deploy from GitHub repo → añade un **Volume** en `/data` y las mismas variables (`DATABASE_PATH=/data/reto.db`).

## Paso 3 — Fase beta con tus amigos

1. Abre la URL de Render en tu móvil → **crea tu cuenta** (serás admin, se genera el código de invitación).
2. Comparte el **código de invitación** (Perfil → Admin) solo con tus beta testers.
3. Cada uno instala la app: menú del navegador → **“Instalar app”**.
4. Activa las **notificaciones push** desde Perfil.
5. Para el email de “recuperar contraseña”, añade las variables SMTP en Render (ver `.env.example`). Sin SMTP, el enlace se imprime en los logs de Render (útil para la beta).

## Cómo cambiar cosas después (beta continua)

| Quiero cambiar… | Dónde |
|---|---|
| **Colores** | `public/index.html` → bloque `:root` (`--violet`, `--pink`, `--bg`…) |
| **Nombre / logo** | `public/index.html` (título), `public/manifest.webmanifest` (`name`, `short_name`), iconos en `public/icons/` |
| **Duración vídeos** (10 s / 30 s) | `server.js` (busca `max = a.kind === 'weekly' ? 30 : 10`) y `public/index.html` (etiquetas) |
| **Hora de resultados** (21:00) | `server.js` (`isResultsVisible`, `hour >= 21`) |
| **Rango de votos** (1–10) | `server.js` (`sc < 1 \|\| sc > 10`) y el slider en `public/index.html` |
| **Más retos / otros temas** | `src/challenges.js` (listas de objetos, personajes, lugares…) |
| **Código de invitación** | App → Perfil → Admin → “Generar código nuevo” (sin tocar código) |

Flujo siempre igual: **editar → `git add . && git commit -m "cambio" && git push`** → Render redespliega solo.

## Retos infinitos: cómo funciona
- Empieza con **500 retos** predefinidos.
- La app vigila el “colchón” de retos sin usar cada minuto. Cuando baja de 30 diarios / 20 semanales, **genera automáticamente retos nuevos únicos** combinando objetos × personajes × lugares × gestos (decenas de miles de combinaciones posibles).
- Nunca se repite un texto: cada reto nuevo se comprueba contra todos los existentes.
- Como admin también puedes generar a mano: `POST /api/admin/challenges/generate` o pedirlo en el chat y lo hacemos.
- Además, la selección es **adaptativa**: los retos que más se completan y mejor se votan tienen más probabilidad de salir, con enfriamiento de 7 días.
