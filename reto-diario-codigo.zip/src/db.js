'use strict';
/**
 * Base de datos SQLite (better-sqlite3, síncrono y rápido).
 * Se crea automáticamente en ./data/reto.db (o $DATABASE_PATH).
 */
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const DATA_DIR = process.env.DATABASE_PATH
  ? path.dirname(process.env.DATABASE_PATH)
  : path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

const dbPath = process.env.DATABASE_PATH || path.join(DATA_DIR, 'reto.db');
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  email         TEXT NOT NULL UNIQUE,
  username      TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  is_admin      INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS challenges (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  text             TEXT NOT NULL UNIQUE,
  type             TEXT NOT NULL,              -- 'foto' | 'video' | 'mixto'
  difficulty       INTEGER NOT NULL DEFAULT 1, -- 1 fácil, 2 medio, 3 difícil
  weekly           INTEGER NOT NULL DEFAULT 0, -- 1 = pool semanal
  assigned_count   INTEGER NOT NULL DEFAULT 0,
  completed_count  INTEGER NOT NULL DEFAULT 0,
  score_sum        REAL    NOT NULL DEFAULT 0,
  score_count      INTEGER NOT NULL DEFAULT 0,
  last_assigned    TEXT    -- fecha YYYY-MM-DD (Madrid) de la última asignación
);

CREATE TABLE IF NOT EXISTS assignments (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  challenge_id INTEGER NOT NULL REFERENCES challenges(id),
  kind         TEXT NOT NULL,   -- 'daily' | 'weekly'
  date_key     TEXT NOT NULL,   -- daily: fecha del día; weekly: fecha del lunes
  created_at   TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(kind, date_key)
);

CREATE TABLE IF NOT EXISTS submissions (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  assignment_id INTEGER NOT NULL REFERENCES assignments(id),
  user_id      INTEGER NOT NULL REFERENCES users(id),
  media_path   TEXT NOT NULL,
  media_type   TEXT NOT NULL,   -- 'image' | 'video'
  duration     REAL,            -- segundos (solo vídeo)
  created_at   TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at   TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(assignment_id, user_id)
);

CREATE TABLE IF NOT EXISTS votes (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  submission_id INTEGER NOT NULL REFERENCES submissions(id),
  voter_id      INTEGER NOT NULL REFERENCES users(id),
  score         REAL NOT NULL,  -- 1.00 .. 10.00
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(submission_id, voter_id)
);

CREATE TABLE IF NOT EXISTS results (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  assignment_id  INTEGER NOT NULL UNIQUE REFERENCES assignments(id),
  winner_user_id INTEGER REFERENCES users(id),
  winner_avg     REAL,
  finalized_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS push_subscriptions (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id),
  endpoint   TEXT NOT NULL UNIQUE,
  p256dh     TEXT NOT NULL,
  auth       TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS password_resets (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id),
  token_hash TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  used       INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS period_winners (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  kind         TEXT NOT NULL,   -- 'weekly' | 'monthly' | 'yearly'
  period_key   TEXT NOT NULL,   -- weekly: lunes YYYY-MM-DD; monthly: YYYY-MM; yearly: YYYY
  user_id      INTEGER REFERENCES users(id),
  total_points REAL,
  wins         INTEGER NOT NULL DEFAULT 0,
  finalized_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(kind, period_key)
);
`);

function getSetting(key) {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : null;
}
function setSetting(key, value) {
  db.prepare('INSERT INTO settings(key, value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value = excluded.value')
    .run(key, String(value));
}

module.exports = { db, getSetting, setSetting };
