'use strict';
/**
 * ~500 retos absurdos predefinidos.
 * Se generan de forma determinista combinando plantillas + listas,
 * garantizando textos únicos. Mitad foto, mitad vídeo, resto mixto.
 * Los semanales (weekly=1) son más difíciles y exigen vídeo ≤30s.
 */

function buildDaily() {
  const out = [];
  const seen = new Set();
  const push = (text, type, difficulty) => {
    if (seen.has(text)) return;
    seen.add(text);
    out.push({ text, type, difficulty, weekly: 0 });
  };

  const objetos = [
    'una cuchara de madera', 'un calcetín huérfano', 'una zapatilla', 'un plátano',
    'una tostadora', 'un peluche', 'una escoba', 'un paraguas', 'una silla de cocina',
    'un libro abierto', 'una botella de agua', 'un cepillo de dientes', 'una gorra',
    'el mando de la tele', 'una planta de interior', 'una olla', 'un cojín',
    'una regadera', 'un despertador', 'una toalla', 'un rollo de papel higiénico',
    'una fiambrera', 'un peine', 'una bufanda', 'un guante', 'una taza',
    'un espejo de mano', 'una linterna', 'un cubo', 'una percha',
  ];
  const personajes = [
    'un superhéroe sin capa', 'un detective de los 70', 'un chef con estrella Michelin',
    'un pirata con parche', 'un robot oxidado', 'un rey sin reino', 'un zombie despistado',
    'un mimo invisible', 'un DJ de pueblo', 'un granjero espacial', 'un mago principiante',
    'un vampiro con miedo a la sangre', 'un ninja torpe', 'un astronauta en pijama',
    'un vaquero sin caballo', 'un científico loco', 'un monje zen estresado',
    'un pescador de sofá', 'un domador de plantas', 'un cartero de cartas imaginarias',
  ];
  const lugares = [
    'en el baño', 'en la cocina', 'en el salón', 'en la calle', 'en el parque',
    'en la escalera', 'en el balcón', 'en el coche', 'en la terraza', 'en el pasillo',
    'en la entrada de casa', 'en el ascensor', 'en el jardín', 'en la azotea', 'en el trastero',
  ];
  const gestos = [
    'haciendo una pose de portada de revista', 'con cara de lunes por la mañana',
    'como si acabaras de ganar la lotería', 'como si te hubieran pillado con las manos en la masa',
    'haciendo el gesto de “no sé nada”', 'como si estuvieras en cámara lenta',
    'con los ojos bizcos', 'haciendo un dab improvisado', 'como si te acabaras de caer',
    'con cara de “esto no estaba en el guion”',
  ];

  // 1) Foto: objeto + personaje + lugar (30*20*15 = 9000 combinaciones, nos quedamos con 160)
  let n = 0;
  outer1: for (let i = 0; i < objetos.length; i++) {
    for (let j = 0; j < personajes.length; j++) {
      for (let k = 0; k < lugares.length; k++) {
        if (n >= 160) break outer1;
        // patrón determinista para no repetir siempre los mismos
        if ((i + j * 3 + k * 7) % 5 !== 0) continue;
        push(
          `Haz una foto de ${objetos[i]} disfrazado de ${personajes[j]} ${lugares[k]}, ${gestos[(i + j + k) % gestos.length]}.`,
          'foto', 1 + ((i + j + k) % 2)
        );
        n++;
      }
    }
  }

  // 2) Vídeo ≤10s: objeto + gesto + lugar (150)
  n = 0;
  outer2: for (let i = 0; i < objetos.length; i++) {
    for (let j = 0; j < gestos.length; j++) {
      for (let k = 0; k < lugares.length; k++) {
        if (n >= 150) break outer2;
        if ((i * 2 + j + k * 5) % 4 !== 0) continue;
        push(
          `Graba un vídeo de máximo 10 segundos donde ${objetos[i]} ${lugares[k]} está ${gestos[j]}. Sin cortes, todo vale.`,
          'video', 1 + ((i + j) % 2)
        );
        n++;
      }
    }
  }

  // 3) Mixto: retos de mímica / sonido / baile (90)
  const mixtos = [
    'Imita a un animal usando solo objetos de cocina. Foto o vídeo de 10 segundos.',
    'Haz una coreografía de 10 segundos usando solo lo que hay en tu nevera.',
    'Explica tu día como si fueras un comentarista deportivo. Vídeo de 10 segundos.',
    'Haz una foto de tu sombra haciendo algo ilegal (en el mundo de las sombras).',
    'Graba 10 segundos de ti bailando como si el suelo quemara.',
    'Haz una foto de dos objetos de casa “peleando”. Ponles diálogo con un cartel.',
    'Graba 10 segundos de ti presentando tu casa como si fuera un anuncio de lujo.',
    'Haz una foto de tu desayuno como si fuera un plato de alta cocina.',
    'Imita una película famosa solo con gestos. Vídeo de 10 segundos.',
    'Haz una foto de tu mano como si fuera un personaje con vida propia.',
    'Graba 10 segundos de ti intentando hablar con tu planta. Muy serio.',
    'Haz una foto de tu ropa tendida como si fuera una pasarela de moda.',
    'Graba 10 segundos de ti haciendo una entrevista a un objeto de casa.',
    'Haz una foto de tu reflejo en una cuchara. Tiene que parecer arte moderno.',
    'Imita a un presentador del telediario contando tu mañana. Vídeo de 10 segundos.',
    'Haz una foto de tu puerta como si fuera la entrada de un castillo.',
    'Graba 10 segundos de ti haciendo yoga con un objeto absurdo.',
    'Haz una foto de tu comida de hoy como si fuera un tesoro pirata.',
    'Graba 10 segundos de ti cantando una canción inventada sobre tu barrio.',
    'Haz una foto de tu casa desde un ángulo que parezca otro planeta.',
  ];
  const extraMixtos = [
    'Haz una foto o vídeo de 10 segundos de {o} {l}, {g}.',
    'Convierte {o} {l} en un instrumento musical. Foto o vídeo de 10 segundos.',
    'Haz un “antes y después” de {o} {l}: primero normal, luego {g}.',
    'Graba o fotografía {o} {l} como si fuera un anuncio de perfumes caros.',
    'Haz una foto de {o} {l} con cara de “acabo de ver un fantasma”.',
  ];
  for (const t of mixtos) push(t, 'mixto', 1 + (out.length % 2));
  n = 0;
  outer3: for (let i = 0; i < objetos.length && n < 70; i++) {
    for (let j = 0; j < lugares.length && n < 70; j++) {
      for (let g = 0; g < gestos.length && n < 70; g++) {
        if ((i + j + g) % 6 !== 0) continue;
        const tpl = extraMixtos[n % extraMixtos.length];
        push(tpl.replace('{o}', objetos[i]).replace('{l}', lugares[j]).replace('{g}', gestos[g]), 'mixto', 1 + (n % 2));
        n++;
      }
    }
  }

  return out; // 160 + 150 + 90 = 400
}

function buildWeekly() {
  const out = [];
  const seen = new Set();
  const push = (text) => {
    if (seen.has(text)) return;
    seen.add(text);
    out.push({ text, type: 'video', difficulty: 3, weekly: 1 });
  };

  const misiones = [
    'Graba un vídeo de máximo 30 segundos donde recreas una escena de película usando solo objetos de casa y sin hablar.',
    'Graba 30 segundos de una coreografía grupal absurda (puedes repetirte con pelucas o filtros) con final épico.',
    'Haz un vídeo de 30 segundos donde explicas cómo sobrevivir a un apocalipsis usando solo 3 objetos de tu cocina.',
    'Graba 30 segundos de ti como si fueras un documentalista narrando la vida salvaje de tu barrio.',
    'Haz un vídeo de 30 segundos donde montas una pasarela de moda con ropa de casa y música dramática.',
    'Graba 30 segundos de una “entrevista exclusiva” a ti mismo en dos personajes distintos.',
    'Haz un vídeo de 30 segundos donde enseñas a hacer algo imposible (leer la mente, teletransportarte…) con trucos caseros.',
    'Graba 30 segundos de una persecución épica por tu casa a cámara lenta, con efectos de sonido hechos con la boca.',
    'Haz un vídeo de 30 segundos donde conviertes tu casa en un programa de cocina de lujo con ingredientes absurdos.',
    'Graba 30 segundos de ti como un mago que falla todos los trucos, pero con mucha confianza.',
    'Haz un vídeo de 30 segundos donde recreas un anuncio de perfume caro en un lugar cutre.',
    'Graba 30 segundos de una batalla de objetos de cocina con banda sonora épica.',
    'Haz un vídeo de 30 segundos donde enseñas tu rutina de “entrenamiento de superhéroe” en casa.',
    'Graba 30 segundos de ti como presentador de un concurso absurdo donde tú eres el único concursante.',
    'Haz un vídeo de 30 segundos donde cuentas una historia de terror usando solo sombras y una linterna.',
    'Graba 30 segundos de una sesión de fotos de moda para tu mascota o un peluche.',
    'Haz un vídeo de 30 segundos donde imitas un tutorial de maquillaje/estilo usando solo objetos de cocina.',
    'Graba 30 segundos de ti haciendo un “noticiario” desde tu barrio con corresponsales imaginarios.',
    'Haz un vídeo de 30 segundos donde montas un escape room casero y lo resuelves en cámara rápida.',
    'Graba 30 segundos de una obra de teatro de 1 minuto condensada: drama, giro y final feliz.',
  ];
  for (const m of misiones) push(m);

  const escenarios = [
    'en un bosque', 'en una playa', 'en un castillo medieval', 'en el espacio exterior',
    'en el salvaje oeste', 'en una ciudad futurista', 'en un barco pirata', 'en un laboratorio secreto',
    'en un mercado medieval', 'en una estación de tren antigua',
  ];
  const protagonistas = [
    'un superhéroe torpe', 'una detective con gabardina', 'un chef espacial',
    'un pirata con miedo al agua', 'un robot enamorado', 'un mago sin varita',
    'un vampiro vegano', 'un ninja con claustrofobia', 'un astronauta con vértigo',
    'un vaquero urbano',
  ];
  const giros = [
    'pero todo sale mal en el último segundo', 'y el final lo decide un objeto de cocina',
    'y tiene que bailar para resolver el conflicto', 'y nadie puede hablar, solo hacer gestos',
    'y todo ocurre en cámara lenta', 'y el villano es tu planta de interior',
    'y la banda sonora la haces solo con la boca', 'y tienes que usar un acento absurdo todo el rato',
  ];
  let n = 0;
  outer: for (let i = 0; i < protagonistas.length; i++) {
    for (let j = 0; j < escenarios.length; j++) {
      for (let k = 0; k < giros.length; k++) {
        if (n >= 80) break outer;
        if ((i + j * 2 + k * 3) % 3 !== 0) continue;
        push(
          `Graba un vídeo de máximo 30 segundos donde ${protagonistas[i]} ${escenarios[j]} ${giros[k]}. Sin cortes si puedes.`
        );
        n++;
      }
    }
  }
  return out; // 20 + 80 = 100
}

const DAILY = buildDaily();
const WEEKLY = buildWeekly();
const ALL = [...DAILY, ...WEEKLY];

// ---------- Generador infinito (sin repeticiones) ----------
// El espacio combinatorio es enorme (decenas de miles de textos únicos),
// así que la app puede crear retos nuevos para siempre sin repetir.
const G_OBJETOS = [
  'una cuchara de madera', 'un calcetín huérfano', 'una zapatilla', 'un plátano',
  'una tostadora', 'un peluche', 'una escoba', 'un paraguas', 'una silla de cocina',
  'un libro abierto', 'una botella de agua', 'un cepillo de dientes', 'una gorra',
  'el mando de la tele', 'una planta de interior', 'una olla', 'un cojín',
  'una regadera', 'un despertador', 'una toalla', 'un rollo de papel higiénico',
  'una fiambrera', 'un peine', 'una bufanda', 'un guante', 'una taza',
  'un espejo de mano', 'una linterna', 'un cubo', 'una percha', 'un tenedor',
  'un colador', 'una plancha', 'un secador de pelo', 'un paraguas roto',
  'una caja de cartón', 'un globo', 'una pelota de tenis', 'un pañuelo',
  'una media', 'un zapato', 'una cuchara', 'un plato', 'un vaso',
];
const G_PERSONAJES = [
  'un superhéroe sin capa', 'un detective de los 70', 'un chef con estrella Michelin',
  'un pirata con parche', 'un robot oxidado', 'un rey sin reino', 'un zombie despistado',
  'un mimo invisible', 'un DJ de pueblo', 'un granjero espacial', 'un mago principiante',
  'un vampiro con miedo a la sangre', 'un ninja torpe', 'un astronauta en pijama',
  'un vaquero sin caballo', 'un científico loco', 'un monje zen estresado',
  'un pescador de sofá', 'un domador de plantas', 'un cartero de cartas imaginarias',
  'un samurái con chanclas', 'un vikingo con miedo al frío', 'un payaso triste',
  'un superhéroe con vértigo', 'una bruja con alergia a las escobas', 'un elfo del supermercado',
  'un dragón vegetariano', 'un unicornio con prisa', 'un fantasma con vergüenza',
  'un robot bailarín', 'un pirata vegano', 'un mago que solo hace trucos con calcetines',
];
const G_LUGARES = [
  'en el baño', 'en la cocina', 'en el salón', 'en la calle', 'en el parque',
  'en la escalera', 'en el balcón', 'en el coche', 'en la terraza', 'en el pasillo',
  'en la entrada de casa', 'en el ascensor', 'en el jardín', 'en la azotea', 'en el trastero',
  'en la puerta del colegio', 'en la plaza del barrio', 'en el portal', 'en la ventana',
  'en el cuarto de la lavadora', 'en la despensa', 'en el garaje',
];
const G_GESTOS = [
  'haciendo una pose de portada de revista', 'con cara de lunes por la mañana',
  'como si acabaras de ganar la lotería', 'como si te hubieran pillado con las manos en la masa',
  'haciendo el gesto de “no sé nada”', 'como si estuvieras en cámara lenta',
  'con los ojos bizcos', 'haciendo un dab improvisado', 'como si te acabaras de caer',
  'con cara de “esto no estaba en el guion”', 'haciendo una reverencia exagerada',
  'como si estuvieras en una película de acción', 'con cara de “acabo de inventar algo”',
  'haciendo el gesto de “ven aquí”', 'como si te acabaran de hacer cosquillas',
  'haciendo un guiño dramático', 'como si estuvieras desfilando',
];
const G_ACCIONES = [
  'bailando como si nadie mirara', 'intentando hacer un mortal', 'haciendo una coreografía improvisada',
  'cantando una canción inventada', 'haciendo una entrevista imaginaria', 'intentando hablar con un animal',
  'haciendo yoga imposible', 'representando una película sin palabras', 'haciendo una pasarela de moda',
  'intentando ser un presentador de TV', 'haciendo una obra de teatro de 10 segundos',
  'imitando a un animal', 'haciendo una sesión de fotos seria', 'intentando hacer magia',
  'haciendo una persecución en cámara lenta', 'fingiendo ser un robot',
];
const G_ESCENARIOS = [
  'en un bosque', 'en una playa', 'en un castillo medieval', 'en el espacio exterior',
  'en el salvaje oeste', 'en una ciudad futurista', 'en un barco pirata', 'en un laboratorio secreto',
  'en un mercado medieval', 'en una estación de tren antigua', 'en un desierto',
  'en una isla desierta', 'en un volcán', 'en un faro', 'en un circo',
];
const G_PROTAS = [
  'un superhéroe torpe', 'una detective con gabardina', 'un chef espacial',
  'un pirata con miedo al agua', 'un robot enamorado', 'un mago sin varita',
  'un vampiro vegano', 'un ninja con claustrofobia', 'un astronauta con vértigo',
  'un vaquero urbano', 'un samurái despistado', 'un vikingo con miedo al mar',
  'un payaso que no sabe hacer chistes', 'un dragón con miedo al fuego',
];
const G_GIROS = [
  'pero todo sale mal en el último segundo', 'y el final lo decide un objeto de cocina',
  'y tiene que bailar para resolver el conflicto', 'y nadie puede hablar, solo hacer gestos',
  'y todo ocurre en cámara lenta', 'y el villano es tu planta de interior',
  'y la banda sonora la haces solo con la boca', 'y tienes que usar un acento absurdo todo el rato',
  'y todo pasa en 30 segundos sin cortes', 'y el protagonista se equivoca de guion',
  'y hay un giro inesperado al final', 'y el público es un peluche',
];
const G_MISIONES = [
  'recreas una escena de película usando solo objetos de casa y sin hablar',
  'montas una coreografía absurda con final épico',
  'explicas cómo sobrevivir a un apocalipsis usando solo 3 objetos de tu cocina',
  'narras la vida salvaje de tu barrio como un documentalista',
  'montas una pasarela de moda con ropa de casa y música dramática',
  'haces una “entrevista exclusiva” a ti mismo en dos personajes distintos',
  'enseñas a hacer algo imposible con trucos caseros',
  'montas una persecución épica por tu casa a cámara lenta',
  'conviertes tu casa en un programa de cocina de lujo con ingredientes absurdos',
  'actúas como un mago que falla todos los trucos, pero con mucha confianza',
  'recreas un anuncio de perfume caro en un lugar cutre',
  'montas una batalla de objetos de cocina con banda sonora épica',
  'enseñas tu rutina de “entrenamiento de superhéroe” en casa',
  'presentas un concurso absurdo donde tú eres el único concursante',
  'cuentas una historia de terror usando solo sombras y una linterna',
  'haces una sesión de fotos de moda para tu mascota o un peluche',
  'imitas un tutorial de maquillaje usando solo objetos de cocina',
  'haces un “noticiario” desde tu barrio con corresponsales imaginarios',
  'montas un escape room casero y lo resuelves en cámara rápida',
  'representas una obra de teatro condensada: drama, giro y final feliz',
  'haces un casting absurdo para elegir al próximo superhéroe',
  'montas una rueda de prensa para anunciar algo totalmente trivial',
  'haces un tutorial de “cómo ser un gato” durante 30 segundos',
  'recreas un partido de fútbol comentado por ti solo',
];
const pick = arr => arr[Math.floor(Math.random() * arr.length)];

/**
 * Genera UN reto nuevo único. `existing` = Set de textos ya usados.
 * Reintenta hasta encontrar uno nuevo (el espacio es gigantesco).
 */
function generateChallenge(kind, existing) {
  for (let intento = 0; intento < 200; intento++) {
    let text, type, difficulty;
    if (kind === 'weekly') {
      type = 'video'; difficulty = 3;
      if (Math.random() < 0.5) {
        text = `Graba un vídeo de máximo 30 segundos donde ${pick(G_PROTAS)} ${pick(G_ESCENARIOS)} ${pick(G_GIROS)}. Sin cortes si puedes.`;
      } else {
        text = `Graba un vídeo de máximo 30 segundos donde ${pick(G_MISIONES)}.`;
      }
    } else {
      const r = Math.random();
      if (r < 0.4) {
        type = 'foto'; difficulty = 1 + Math.floor(Math.random() * 2);
        text = `Haz una foto de ${pick(G_OBJETOS)} disfrazado de ${pick(G_PERSONAJES)} ${pick(G_LUGARES)}, ${pick(G_GESTOS)}.`;
      } else if (r < 0.8) {
        type = 'video'; difficulty = 1 + Math.floor(Math.random() * 2);
        text = `Graba un vídeo de máximo 10 segundos donde ${pick(G_OBJETOS)} ${pick(G_LUGARES)} está ${pick(G_GESTOS)}. Sin cortes, todo vale.`;
      } else {
        type = 'mixto'; difficulty = 1 + Math.floor(Math.random() * 2);
        text = `Haz una foto o vídeo de 10 segundos de ti ${pick(G_ACCIONES)} ${pick(G_LUGARES)}.`;
      }
    }
    if (!existing.has(text)) return { text, type, difficulty, weekly: kind === 'weekly' ? 1 : 0 };
  }
  return null; // prácticamente imposible
}

module.exports = { DAILY, WEEKLY, ALL, generateChallenge };
