# ⚡ Reto Diario — Amigos

App web/PWA para Android: reto diario absurdo entre amigos, reto semanal difícil, votación secreta y ranking.

## Cómo funciona
- **Registro** con email, usuario y contraseña protegido por **código de invitación**. El **primer usuario** es admin y genera el código (visible en Perfil → Admin).
- **Reto diario** (foto o vídeo ≤10 s) nuevo cada día a las **00:00** (hora Madrid).
- **Reto semanal** (vídeo ≤30 s, más difícil) de **lunes a domingo**.
- **~500 retos absurdos** predefinidos (400 diarios + 100 semanales) con **selección adaptativa**: los retos que más se completan y mejor se votan vuelven a salir; enfriamiento de 7 días para no repetir.
- **Votación secreta** de **1.00 a 10.00** (2 decimales). No puedes votar tu propia entrega.
- De **21:00 a 00:00** se revelan notas medias y quién gana el reto del día.
- Al cerrar cada **semana / mes / año** se calcula el **ganador del periodo** (suma de notas medias) y se muestra en Ranking → Ganadores.
- **Notificaciones push**: reto nuevo, recordatorio 20:00, ganador del día y del periodo.
- **Recuperar contraseña** por email (enlace de 1 hora).
- **PWA instalable** en Android (Añadir a pantalla de inicio).

## Ejecutar en local
```bash
npm install
cp .env.example .env   # edita JWT_SECRET y APP_URL
npm start
# abre http://localhost:3000
```
Sin SMTP configurado, el enlace de recuperación se imprime en la consola del servidor (modo desarrollo).

## Despliegue gratuito (Render / Railway)
1. Sube esta carpeta a GitHub.
2. **Render**: New → Web Service → conecta el repo. Usa el `render.yaml` incluido (incluye disco persistente de 1 GB en `/data`). Define `APP_URL` con tu dominio y las variables SMTP.
3. **Railway**: New Project → Deploy from GitHub repo (Dockerfile incluido). Añade un **Volume** montado en `/data` y define `DATABASE_PATH=/data/reto.db`, `JWT_SECRET`, `APP_URL` y SMTP.
4. ⚠️ **Importante**: SQLite necesita disco persistente; sin volumen, la BD se borra en cada despliegue/reinicio.

### Variables de entorno
| Variable | Para qué |
|---|---|
| `PORT` | Puerto (Render/Railway lo inyectan) |
| `JWT_SECRET` | Secreto de sesiones |
| `APP_URL` | URL pública (enlaces de recuperación) |
| `DATABASE_PATH` | Ruta de la BD SQLite |
| `SMTP_HOST/PORT/USER/PASS/FROM` | Email de recuperación |
| `VAPID_*` | Push (opcional, se autogeneran) |

## Estructura
```
server.js          API + lógica (retos, votos, rankings, push, email)
src/db.js          Esquema SQLite
src/challenges.js  500 retos absurdos
public/            Frontend PWA (index.html, manifest, service worker, iconos)
uploads/           Fotos/vídeos subidos
data/              Base SQLite (persistente en producción)
```
